# 公开地图与建筑资料补充

此流程是独立建模器的可选联网阶段，使用 Python 标准库，不依赖原游戏工程或特定搜索插件。生成和导出仍可离线运行。用户禁止联网时只用提供的地图/资料，并说明缺失字段。

## 选择渠道

| 渠道 | 实际用途 | 限制 |
|---|---|---|
| 高德 Web Service POI | 校名、校区、楼名、地址、位置、分类 | 需要用户的 Web服务 Key；当前适配器不提供确定的楼高、轮廓或立面 |
| OpenStreetMap / Overpass | 已标注的建筑轮廓、height、building:levels、roof:shape、材料/颜色等 | 覆盖不完整；社区标签不是实测保证；注意 building:part 与多边形内环 |
| 学校官网、建设单位/建筑设计单位官网、规划公示 | 建筑总高、层数、体量、屋顶、立面照片及改造年代 | 核对校区、日期和建筑身份；原图不自动视为可再分发素材 |
| 用户提供的照片、平面图、公开地图截图 | 交叉确认布局与外观 | 透视照片不能直接推导精确高度；地图可见不等于允许抓取内部瓦片/API |

先确定“学校＋校区＋城市”，从地图确认少数地标与邻接关系；同名校区不自动合并。没有足够身份信息时先读图建布局，再询问关键缺项。以完整楼名加“建筑高度 / 层数 / 建筑设计 / 校园地图”搜索优先来源；不能把搜索摘要当作原文已核实。打开来源页后整理事实，不复制整篇文章。

官网检索使用执行 Agent 已有的搜索/网页阅读工具；技能不绑定某个付费搜索服务。没有搜索工具时仍可使用内置 OSM/高德脚本，或阅读用户给出的公开页面。不得声称未打开的网页已核实，也不为此强制安装浏览器插件。

## 高德 POI

```text
python -X utf8 <技能目录>/scripts/map_evidence.py amap --keywords "复旦大学 光华楼" --city "上海" --out <工作目录>/amap-evidence.json
```

默认读取环境变量 `AMAP_WEB_SERVICE_KEY`（可用 `--key-env` 指定其他变量名）。不要把 Key 写入命令、SKILL、输出包、日志或聊天；请用户在本机配置。无 Key 时继续 OSM 与官网路线，不把整个建模流程阻塞在高德上。每次只请求一页（25 条）；可显式 `--page 2`，上限 10 页，不循环扫城、不自动重试配额错误。所用 API 有账号权限/配额限制，不能承诺免费无限调用。

当前采用公开 `/v3/place/text`，返回筛选后的名称、位置、地址和类型。室内 POI 的 floor 字段只表示所在楼层，不能当整栋楼的层数；地图 3D 显示效果也不代表有可下载的开放建筑模型。需要额外服务时先确认官方接口和用户权限，不逆向私有地图瓦片。

## OSM 建筑资料

```text
python -X utf8 <技能目录>/scripts/map_evidence.py osm --bbox "南纬度,西经度,北纬度,东经度" --out <工作目录>/osm-evidence.json
```

四项为实际数字，WGS84，单轴跨度不超过 0.08 度；从可靠地图定位校园范围，不猜测坐标。默认 Overpass de，可显式 `--endpoint kumi`；服务超时/限流时停止，缩小范围或稍后再试，保留缺失记录。

解析 height（默认米，也识别 ft/feet）、building:levels、roof:height、min_height、roof:shape、building/roof 的 colour/material 和 building:architecture。缺失字段为 null。`--floor-height 3.2` 才启用“层数×假定层高＋已知屋顶高度”的低置信估计，写入独立 estimatedHeight；不覆盖 height。层高不是统一真实值，估计还须考虑挑空、设备层、裙房与屋顶。

way 的 geometry 保留轮廓点，relation 保留 outer/inner 成员线段；未自动拼合成有效多边形。不要丢失中庭孔洞，不要把多个 building:part 重复当成多栋楼。OSM 整体高度包含屋顶；绝对海拔 ele 不是建筑高度。

已有 API 响应可用相同命令加 `--response <response.json>`，不联网、无需 Key；来源采集时间记为 unknown，仅处理时间有当前时间，不假装刚从服务器取得。

## 坐标、证据与造型

- 高德使用 GCJ-02，OSM 使用 WGS84；截图可能还有旋转/缩放。不得只按数值近邻直接匹配、叠加两者。先保留各自 CRS，通过可靠同名地标与道路关系确认身份；必要时使用受支持的坐标转换并记录方法、误差。不要简单改 CRS 标签冒充转换。
- 经度方向需考虑纬度缩放，平面图与实际轮廓对齐后，明确统一的 `metresPerGameUnit`。游戏 v1 h 上限 30、floors 上限 10；超限要显式记录体量压缩或视觉层数简化，不能静默截断、把真实米数当游戏单位。
- 仅将已确认属于同一建筑的字段采用到校园布局；同一字段冲突时保留各来源值、时间、取舍依据，不平均混合历史/现状，也不按“搜索第一条”选择。
- 高度与造型没有证据时保留估测。官网写“两层”是来源记录；从照片数出的层数是视觉推断；依据楼层估算高度是估算，三者不能混称测量。
- style 数据先指导选择现有 recipe、w/d/h、floors、tint。并非每个配方都支持每个参数；四坡礼堂的 h 仍固定，任意屋顶形状/轮廓尚不能原样导入。无法表达的材质、圆形/倾斜体块必须记录为简化，不能只写无效 roof 参数声称已还原。
- `source.evidenceMatches` 按 regionId 记录 featureId、采用字段、源值、模型值、比例、取舍理由；未匹配楼保留 missing 信息。

例如光华楼总高来源值 142 m，在校园使用 6 m/游戏单位时，目标体量约为 23.67 游戏单位。记录 `regionId`、`featureId=official:fudan-guanghua`、`sourceHeightMetres=142`、`metresPerGameUnit=6` 和配方调整理由。各配方的 h 不一定等于最终包围盒总高（可能还含基座、屋顶），实际模型需回读检查，不能只填 h 就宣称精确复原。若校园布局并未整体标定米制比例，应把竖向压缩明确记为艺术化处理。

## 证据文件和交付

脚本输出 `campus-map-evidence` v1：sources（URL/查询范围/CRS/采集时间/归属与许可）、features（逐楼字段、来源和置信度）、coverage、warnings。官网事实由 Agent 使用相同格式记录，示例见 `../assets/research-example.json`，不要复用示例事实到其他学校。

```text
python -X utf8 <技能目录>/scripts/build_package.py --input <校园.json> --out <输出目录> --evidence <osm-evidence.json> --evidence <official-evidence.json>
```

附加的 evidence 不自动覆盖几何；Agent 先根据证据调整 JSON，再构建。工具把 evidence.json、SOURCES.md 放进模型包，并在 campus.json/source 与 layout-analysis 中保留来源。交付时说明真正采用了哪些字段、哪些仍未知，不把“查询完成”当成“高度已确认”。

使用 OSM 数据时保留贡献者署名、ODbL 和来源链接；发布衍生地图/数据时按 ODbL 要求处理。高德数据按其许可范围使用，不能因为可查询就称其为开放数据。照片默认只作造型参考，不下载进材质包，除非有相应使用权并保存许可记录。

## 官方参考（2026-09-25 核对）

- [高德 POI 接口与 Key](https://developer.amap.com/api/webservice/guide/api/search/)
- [高德 GCJ-02 坐标说明](https://developer.amap.com/faq/advisory/others/39838)
- [OSM height](https://wiki.openstreetmap.org/wiki/Key:height)、[building:levels](https://wiki.openstreetmap.org/wiki/Key:building:levels)、[roof:shape](https://wiki.openstreetmap.org/wiki/Key:roof:shape)
- [Overpass API](https://wiki.openstreetmap.org/wiki/Overpass_API)、[OSM 许可](https://www.openstreetmap.org/copyright)
