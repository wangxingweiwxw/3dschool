# 独立构建与导入

技能根目录包含完整的 runtime，无需查找原始 3Dschool 工程。Python 3.10+ 与本机 Chrome / Edge / Chromium 是仅有的执行环境要求；不使用 pip 包、Node、npm、Vite 或在线 JS 库。

## 构建

从当前技能目录或任意其他工作目录运行，路径以安装位置为准：

```text
python -X utf8 <技能目录>/scripts/doctor.py
python -X utf8 <技能目录>/scripts/build_package.py --input <已编写的campus.json> --out <输出父目录>
```

Windows 自动查找 Program Files / LocalAppData 下的 Chrome、Edge；macOS 查找 Applications；Linux 查找 PATH 中的 Chrome、Chromium、Edge。自定义位置可传 `--browser <浏览器可执行文件>`（也接受兼容别名 `--chrome`）。复杂地图可增加 `--timeout 480`，默认 240 秒。

工具验证 runtime 校验和，启动绑定 127.0.0.1 的随机端口 HTTP 服务，用临时用户目录启动无头浏览器，通过内置 ES module/import map 运行建模代码。生成完毕后关闭本次服务与浏览器、清理临时用户目录。无需手工启动 5173 端口服务，不读取任何目标游戏工程，也不使用个人浏览器登录状态。

输入是 Agent 根据图片解释、编写的 JSON，不是图片本身。工具不内置自动 OCR，不以四栋楼模板代替真正读图。校验或寻路失败时修正输入；不要忽略异常交付缺损包。脚本拒绝覆盖已有同名目录/ZIP，修改时选新输出目录或显式版本 ID。

默认 --profile complete，要求 source.modelingPlan.inventory 和 source.researchLog；具体字段见 complete-delivery.md。局部验证及合成模板显式使用 --profile draft，并保留草稿标记。构建会自动审计生成 ZIP，也可单独运行 `python -X utf8 <技能目录>/scripts/check_package.py <模型包ZIP>`。

输出 `<输出父目录>/<campus.id>/` 与同名 ZIP，包含 GLB、JSON、PNG、路线报告、来源分析、哈希清单与导入说明。PNG 是 GLB 回读后渲染结果；所有几何/纹理均由内置代码生成，不需外部贴图。`validation.json.generator` 记录独立生成器版本与实际加载的内置模块列表。

GLB 查看器需支持 glTF 2.0 与 EXT_mesh_gpu_instancing。角色、夜景和动态透视属于漫游运行时，GLB 是静态校园；配套 JSON 用于兼容 v1 文件契约的 3Dschool。

## 使用生成结果

**网页导入**：在支持校园包的 3Dschool 网页右上角点击“校园”，选择 `campus.json` 或模型包 ZIP，点击“进入这座校园”。数据保存在当前网站的浏览器中，换设备需重新导入。JSON 上限 2 MB、ZIP 上限 80 MB；若 ZIP 过大，解压后选择 JSON。网页只执行结构校验，交付前仍须使用本技能验证实际路线。

**随游戏部署**：这一步才需要用户指定目标游戏路径。用户没有要求安装进游戏时，交付模型包即可。

```text
python -X utf8 <技能目录>/scripts/import_package.py --package <已生成模型包目录> --project <用户指定的游戏工程目录>
```

该可选工具检查文件哈希，只将 JSON 复制到目标 `public/campuses/<campus.id>/campus.json`。`--dry-run` 只检查，不写文件。同名内容不会自动覆盖。目标游戏必须已实现校园包加载接口；缺少接口时明确报错，不要求生成阶段寻找游戏代码。不能声称任何未知游戏都能直接导入。

重新构建游戏后部署完整 dist，以 `https://网站地址/?campus=<campus.id>` 访问。GLB 不必上传到游戏服务器。

## 维护安装包

`runtime/manifest.json` 锁定内置文件版本和 SHA-256；普通执行不修改它。维护者有意修改建模代码后，运行以下命令更新清单、检查 JS 导入闭包并重打包：

```text
python -X utf8 <技能目录>/scripts/package_skill.py --refresh-inventory --out <技能目录之外的ZIP路径>
```

普通重新打包省略 `--refresh-inventory`。不能通过刷新清单掩盖用户安装包中缺失或被改坏的依赖。

## 附带地图证据

可重复传入 `--evidence <证据.json>`。生成包增加 evidence.json、SOURCES.md，campus.json/source 保留来源索引；资料不会自动覆盖模型，请先按 public-map-research.md 核对身份、坐标与尺度，将采用结果写进输入布局。联网查询脚本与运行时均已内置，不影响离线生成模式。
