# 完整建模、可复现交付与包体积诊断

## 默认交付和自检

技能安装 ZIP 包含代码、Three.js、资料和布局样例；它可小于 1 MB。生成的校园 ZIP 另含 GLB 和预览，通常大得多。用户只要求 JSON 时，几十 KB 的 JSON 也可以重建同一校园。不能仅按 ZIP 大小判断质量或声称精确复原。

完整交付使用内置 build_package.py；不要自行用几个 Box 写个 GLB、只压 JSON 或绕过纹理/植被/回读来宣称完整包。图像分析与建模清单仍由执行 Agent 完成，生成器不负责自动 OCR 或自动查全楼名。缺少联网、Python、浏览器时明确具体限制，不能用缩减产物冒充成功。

`check_package.py <目录或ZIP>` 独立检查必要文件、SHA-256、GLB 二进制与嵌入纹理、网格、路线集合、出生点/回读报告。检查输出打印楼数、树数、图像数、GLB 字节数；报缺件就修复，不补空文件或伪造报告。结构通过不等于地理精度通过。ZIP <1 MB 时先查是否只是安装包或 JSON 包；真完整的小模型也可能合理，不设人为体积下限。

## 观察清单（先于建模）

真实地图默认 complete。将图示校区分成可辨识片区，记录主体建筑、门、操场、水体；每项必须映射一个或多个 regionId，或明确遗漏原因。逐楼匹配以校名/校区、至少两个邻接地标、轮廓或所在道路为依据，不能把同名搜索结果直接套到最近方块。

```json
{
  "source": {
    "modelingPlan": {
      "mapBasis": "附件文件名、可见范围、地图年代与方向/比例假设",
      "inventory": [
        {"id":"east-gate","kind":"gate","label":"东门","nameStatus":"map-read","regionIds":["east-gate-model"],"orientation":{"passageAxis":"east-west","basis":"东侧校界、门外道路与门内轴线；无实测角度"}},
        {"id":"annex","kind":"building","label":"附属体块","nameStatus":"unresolved","regionIds":["annex-model"],"uncertaintyReason":"已查官方校园图，无法区分独立楼名"}
      ]
    },
    "researchLog": [
      {"status":"read","url":"https://学校官网/校园图","queries":["学校 校区 校园平面图"],"result":"真正阅读后的采用/未采用结论"}
    ]
  }
}
```

`nameStatus` 可用 map-read/verified/unresolved；附属体块和真实独立楼栋要区分。无法确认名称的楼保持中性内部 label，teaching-block 设 showSign=false，不捏造教学用途。无联网时 researchLog 写 status=offline/unavailable/user-prohibited 和原因，不编造 URL 或已检索结论。清单覆盖率是对已观察清单的覆盖，不证明 Agent 没漏看原图；交付前必须按片区目视核对。

默认外部检索至少尝试学校官网地图/新生手册与不确定建筑的精确检索；仅有搜索摘要不能标 verified。若已有来源明确答案，无需机械重复搜索。记清来源年代，不把历史规划图当现状。楼高、样式、名称、朝向分别记录置信度。

## 校门专项

校门横梁方向和穿行方向相互垂直。默认 rotation=0：梁沿 X、穿行南北；rotation=1.5707963267948966：梁沿 Z、穿行东西。两种 gate 配方支持正负90度整数倍；一般建筑不支持。旋转后检查门柱位置、门洞可穿行、内外 approach/spawn、相接道路、植被和小地图。无法表达的斜向门不能谎称精确角度。

旧 3Dschool 部署会拒绝非零 rotation；先升级兼容的游戏运行时再导入。不能为了旧版通过校验而默默把校门转回错误方向。需要旧版兼容时可另交明确标注的近似版本。

## 全尺寸独立复现

先运行 doctor，然后从任意目录执行（没有 D 盘或原游戏也能运行）：

```text
python -X utf8 <skill>/scripts/build_package.py --input <skill>/assets/sjtu-xuhui/campus.json --evidence <skill>/assets/sjtu-xuhui/evidence.json --out <新的输出父目录>
python -X utf8 <skill>/scripts/check_package.py <输出父目录>/sjtu-xuhui-map-v2.zip
```

案例有 44 个建筑/校门体块、22 个地标、12 枚记忆，完整 GLB 包含植被和嵌入纹理。它用于验证安装是否完整、生成路径是否正确；不把 44 栋、12 枚或 10 MB 变成所有学校的硬性标准。实际图中只有几栋楼就如实建几栋。

查看 preview.png，并与输入图核对校园分区、楼宇邻接、入口穿行方向和明显轮廓。真实游戏导入测试仅在用户提供目标项目时进行；独立技能不假设任何项目路径。四栋楼模板只用于草稿烟测，命令显式添加 --profile draft。
