# 校园包 v1 格式

入口为纯 JSON：`{"format":"3dschool-campus","version":1,"source":{},"campus":{}}`。不能使用函数、模块导入、远程资产或 Math.PI 等 JS 表达式；颜色用整数，角度用实际数字。完整可运行例子见 `../assets/campus-template.json`。实际校验位于技能内置的 `../runtime/src/data/campusPackage.js`；建模配方在 `../runtime/src/world/`。

## 必需字段

| 字段 | 约定 |
|---|---|
| id / name | 全局唯一小写英文短 ID / 学校名称；ID 用于目录及独立存档 |
| bounds | width、depth 为 24–300 的整数，寻路网格直接使用该尺寸 |
| mapBounds | width、depth ≥ bounds 对应尺寸且 ≤ 340 |
| spawn | x,z 可站立；yaw=3.141592653589793 面北 |
| intro | x,z 开场中心，size=23–180 镜头范围 |
| districts | 非空；每项 id,name,x,z,w,d,tint；tint=#RRGGBB |
| tasks | 每项 id,label,icon,zone；zone 是片区 ID 或 all |
| landmarks | id,title,quote,speech,zone,x,z,labelY,radius,approach:{x,z}；任务地标另有 taskId |
| memories | 非空；每项 id,title,text,x,z；tasks 必须有 id=memories |
| regions | 区域列表，见下文 |
| swans / crossings | 必須为数组，可为空；每项 x,z；天鹅放在水体中 |
| palette | 可选，覆盖已有配色字段的整数值，不保证改变固定地面纹理 |
| entryGateId | 可选，主校门区域 ID；引擎按固定规格加两侧墙，重新检查通行 |

列表内部 ID 不重复。除 memories 外每个任务都应关联地标。导航和触发中心是 `approach`，不能省略或放入建筑。文本用于显示，不放 HTML。

## 坐标与区域

原点为校园中心，+X 东、+Z 南、+Y 上。用统一像素比例映射 x,z，不无说明地分别拉伸两轴。无比例尺时单位是游戏单位。

| type | 字段与功能 |
|---|---|
| path / plaza / road | id,x,z,w,d，可选 label；矩形步道、广场、道路 |
| water | id,x,z,w,d；矩形湖面，完整实心水体碰撞；不支持涉水、桥、多边形 |
| sports | id,x,z,w,d；建议 w≥30,d≥24；看台有碰撞 |
| building | id,x,z,w,d,h,recipe,label；可选 tint,floors,front，取决于配方 |
| prop-row | id,x,z,kind,count,dx?,dz?；kind=lamp/bench，count=1–60 整数，dx/dz 是整排跨度 |

区域在 bounds 内。2.2 生成器及同步升级的游戏在 v1 中允许 ceremonial-gate / small-gate 的 rotation 为 90° 整数倍（范围 -2π..2π），旋转后边界、门柱碰撞和植被避让同步更新；其他区域仍只允许 0。默认门梁沿 X、南北穿行；rotation=1.5707963267948966 时门梁沿 Z、东西穿行。旧游戏部署会拒绝非零 rotation，需要更新游戏。business-school 支持 front=-1 朝北。斜路用相连矩形近似，并记录调整。

地面、草木自动生成。不添加被忽略的 lawn/grove/bridge。建筑之间留约 3 单位通路；人物碰撞在模型碰撞边界外再膨胀 0.58 单位。

## 配方

| recipe | 适用与约束 |
|---|---|
| teaching-block | 教学、实验、宿舍楼；w,d,h,floors,tint 生效；正面朝南 |
| teaching-block 的 showSign | false 隐藏墙面楼名，适用于未决名称或组合附翼；不改变内部 label/regionId |
| library | 前厅柱廊图书馆；w,d,h 生效，固定三排窗；台阶向南外伸 |
| business-school | 学院楼；w,d,h,tint 生效，front=-1 朝北 |
| classical-hall | 礼堂四坡屋顶；w,d 生效，墙高约 4.2，h 不控制实际高度 |
| ceremonial-gate / small-gate | 校门；按实际 build 函数确定柱子碰撞，不假设 w,d,h 都能缩放 |
| twin-tower | 双塔；h 生效；底座宽深固定，实际碰撞约 10.4×6.8 |
| clock-tower | 钟楼；h 生效，底面固定，顶部装饰高于 h |
| shop / white-house | 低层店铺、院舍；w,d 生效，高度基本固定 |
| academic | 简单教学楼；w,d,h 生效，窗数固定 |
| wayfinding | 路牌，固定造型，无建筑碰撞 |

按真实外伸范围安排入口和道路，最终依赖真实碰撞与寻路验证，不能仅从 JSON w,d 猜塔楼或门洞尺寸。

## 输出模型

GLB 含建筑、屋顶、地面、植被、静态水面、天鹅及嵌入纹理。植被使用 EXT_mesh_gpu_instancing。角色、任务图标、标签和粒子由游戏生成，不属于 GLB。夜景、水波、透视和碰撞由配套 JSON 重建。仅导入 GLB 不等于导入可玩校园。
