# 安装独立版 school-map-to-campus

将 ZIP 中的整个 `school-map-to-campus` 文件夹安装到 Agent 的技能目录。例如 Codex 的个人技能目录为 `~/.codex/skills/`。文件夹可以位于任意盘符与用户名下；保留内部相对结构，不要只安装 SKILL.md。

安装后应同时存在：

```text
school-map-to-campus/
  SKILL.md
  INSTALL.md
  agents/openai.yaml
  scripts/          # 生成、环境检查、可选导入、打包工具
  assets/           # 可运行 JSON 模板
  references/       # 格式、读图、构建说明
  runtime/
    index.html
    browser-driver.js
    manifest.json
    src/            # 建模/纹理/碰撞/寻路/校验/GLB 导出
    vendor/three/   # Three.js 0.170.0 及 MIT LICENSE
    THIRD_PARTY_NOTICES.md
```

需要 **Python 3.10+** 和本机 **Chrome、Edge 或 Chromium**。不需要 3Dschool 源码、不需要任何固定盘符、不需要 Node/npm/Vite/Playwright，也无需 pip install。Windows、macOS、Linux 浏览器自动发现路径已实现；本版实际生成验证使用 Windows Chrome，其他系统尚未实机验证。

Python 与浏览器属于平台运行环境，未把不同操作系统的大型可执行程序塞进 ZIP。所有校园生成代码、库文件、模板与许可证均已内置；执行时不从 CDN 下载资源。安装上述运行环境后，生成流程可离线运行。Agent 自身识别地图图片是否需要联网，由其模型环境决定。

安装 Agent 应先运行：

```text
python -X utf8 <安装目录>/scripts/doctor.py
```

首次验证可使用内置合成模板（它不代表真实学校）：

```text
python -X utf8 <安装目录>/scripts/build_package.py --input <安装目录>/assets/campus-template.json --out <新的输出目录> --profile draft
```

正常使用：附上学校地图，调用 `$school-map-to-campus`，要求根据图片生成校园模型包。Agent 读图编写布局，内置生成器完成模型、预览、可达性验证与 ZIP。

2.2 新增完整徐汇案例、默认完整建模清单检查、校门90度旋转和 check_package.py 交付审计。完整案例独立复现命令见 references/complete-delivery.md；无须旧对话、原工程或任何固定盘符。通用网络检索由执行 Agent 的工具提供，无工具时如实记录限制。安装 ZIP 小于 1 MB 不代表产出的校园 ZIP 缺少模型，两者用途不同。

报错时：

- 找不到 Python：安装 Python 3.10+ 后重试。
- 找不到浏览器：安装 Chrome/Edge/Chromium，或用 `--browser` 指向已有可执行文件。
- 缺少 runtime 文件/哈希不匹配：重新安装完整 ZIP，不要从原始开发工程补文件。
- WebGL 或超时错误：检查浏览器 WebGL 支持与资源占用；大校园可用 `--timeout` 延长等待。
- 不支持旧 `--project` / `--url` 构建参数：独立版生成不需要这些参数。`--project` 只用于可选的 `import_package.py` 游戏安装步骤。

## 可选公开地图资料增强

新版支持高德 POI、OSM 建筑轮廓/高度标签与学校官网资料。仅这个步骤需要联网；生成器仍可离线运行。高德使用环境变量 AMAP_WEB_SERVICE_KEY，未配置时可使用 OSM 与官网资料。无需新增 Python 包；详情见 references/public-map-research.md。证据文件可通过 build_package.py 的 --evidence 参数随模型包输出。
