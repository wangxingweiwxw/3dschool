"""Fetch optional public map evidence; stdlib only, never silently invent heights."""
import argparse,datetime,hashlib,json,math,os,re,sys
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError

ENDPOINTS={'de':'https://overpass-api.de/api/interpreter','kumi':'https://overpass.kumi.systems/api/interpreter'}
AMAP='https://restapi.amap.com/v3/place/text'
LIMIT=16*1024*1024

def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def numeric(value):
    try:
        value=float(value)
        return value if math.isfinite(value) and 0<value<3000 else None
    except (TypeError,ValueError):return None
def metres(value):
    if not isinstance(value,(str,int,float)):return None
    match=re.fullmatch(r'\s*(\d+(?:\.\d+)?)\s*(m|metres|meters|ft|feet)?\s*',str(value),re.I)
    if not match:return None
    number=float(match[1])
    if not 0<=number<3000:return None
    return round(number*.3048,4) if (match[2] or '').lower() in ('ft','feet') else number
def text(value):return value if isinstance(value,str) else ''
def fetch(url,data=None):
    req=Request(url,data=data,headers={'User-Agent':'SchoolMapToCampus/2.1 (small user-requested campus query)','Accept':'application/json'})
    try:
        with urlopen(req,timeout=40) as response:
            content=response.read(LIMIT+1)
            if len(content)>LIMIT:raise ValueError('Response exceeds 16 MB; narrow the campus bounding box.')
            return json.loads(content)
    except HTTPError as error:raise RuntimeError(f'Map service HTTP {error.code}; check quota/availability. No automatic retry.') from None
    except (URLError,TimeoutError):raise RuntimeError('Map service unavailable or timed out; use an existing response file or continue with documented missing data.') from None
    except json.JSONDecodeError:raise RuntimeError('Map service returned invalid JSON.') from None
def source(provider,url,crs,query,raw,offline=False):
    return {'id':provider+'-'+hashlib.sha256(json.dumps(query,sort_keys=True).encode()).hexdigest()[:10],
      'provider':provider,'url':url,'crs':crs,'retrievedAt':None if offline else stamp(),'processedAt':stamp(),
      'acquisition':'user-supplied-response' if offline else 'live-api','query':query,
      'responseSha256':hashlib.sha256(json.dumps(raw,sort_keys=True,ensure_ascii=False).encode()).hexdigest()}
def envelope(src,features,warnings):
    return {'format':'campus-map-evidence','version':1,'sources':[src],'features':features,'warnings':warnings,
      'coverage':{'features':len(features),'explicitHeight':sum(f.get('height') is not None for f in features),'estimatedHeight':sum(f.get('estimatedHeight') is not None for f in features)},
      'modelingNote':'Evidence only. Match campus/building identity and coordinates before applying; missing fields remain unknown.'}

def normalize_osm(raw,src,floor_height=None):
    if not isinstance(raw.get('elements'),list):raise ValueError('Invalid Overpass response: elements array missing.')
    if raw.get('remark'):raise ValueError('Overpass reported an incomplete/error response; narrow the area and retry later.')
    src['attribution']='© OpenStreetMap contributors';src['license']='ODbL-1.0';src['licenseUrl']='https://www.openstreetmap.org/copyright'
    src['datasetTimestamp']=raw.get('osm3s',{}).get('timestamp_osm_base')
    features=[]
    for e in raw['elements']:
        tags=e.get('tags',{})
        if not (tags.get('building') or tags.get('building:part')):continue
        if e.get('type') not in ('node','way','relation') or not isinstance(e.get('id'),int):continue
        url=f'https://www.openstreetmap.org/{e["type"]}/{e["id"]}'
        def tag(field,value,unit=None):
            return None if value is None else {'value':value,'unit':unit,'method':'source-tag','sourceField':field,'sourceUrl':url,'confidence':'medium','note':'Community-reported, not independently surveyed by this tool.'}
        height=metres(tags.get('height'));levels=numeric(tags.get('building:levels'));roof_height=metres(tags.get('roof:height'))
        style={key:tag(key,tags[key]) for key in ['roof:shape','roof:colour','roof:material','building:colour','building:material','building:architecture'] if isinstance(tags.get(key),str)}
        geometry=[]
        if e.get('geometry'):geometry.append({'role':'outline','points':e['geometry'],'closed':e['geometry'][0]==e['geometry'][-1]})
        for m in e.get('members',[]):
            if m.get('geometry'):geometry.append({'role':m.get('role',''),'points':m['geometry'],'closed':m['geometry'][0]==m['geometry'][-1]})
        center=e.get('center') or ({'lat':e['lat'],'lon':e['lon']} if 'lat' in e and 'lon' in e else None)
        feature={'id':f'osm:{e["type"]}/{e["id"]}','name':text(tags.get('name') or tags.get('name:zh')),'sourceId':src['id'],'sourceUrl':url,'crs':'WGS84','center':center,'geometry':geometry,
          'buildingPart':bool(tags.get('building:part')),'height':tag('height',height,'m'),'levels':tag('building:levels',levels,'floors'),'roofHeight':tag('roof:height',roof_height,'m'),
          'minHeight':tag('min_height',metres(tags.get('min_height')),'m'),'style':style,'estimatedHeight':None}
        if height is None and levels and floor_height:
            feature['estimatedHeight']={'value':round(levels*floor_height+(roof_height or 0),3),'unit':'m','method':'levels-estimate','confidence':'low','sourceField':'building:levels','sourceUrl':url,
              'assumptions':{'metresPerFloor':floor_height,'roofHeightMetres':roof_height or 0,'roofHeightUnknown':roof_height is None},'note':'Estimated total from levels; cannot replace a reported/measured height.'}
        features.append(feature)
    return envelope(src,features,['OSM coverage and heights may be missing or outdated.','Relation member geometry is unassembled; join outer rings and preserve holes before using footprints.','Do not count building parts as separate whole buildings.'])

def normalize_amap(raw,src):
    if str(raw.get('status'))!='1':
        code=str(raw.get('infocode','unknown'))
        raise ValueError('Amap API rejected the request (infocode '+(code if code.isdigit() else 'unknown')+'). Check Key type, permissions and quota.')
    if not isinstance(raw.get('pois'),list):raise ValueError('Invalid Amap response: pois array missing.')
    src['attribution']='高德地图';src['license']='Amap service terms; public access is not an open-data license';src['licenseUrl']='https://lbs.amap.com/home/terms/'
    features=[]
    for poi in raw['pois']:
        coords=text(poi.get('location')).split(',');point=None
        if len(coords)==2:
            try:
                lon,lat=map(float,coords)
                if -180<=lon<=180 and -90<=lat<=90:point={'lon':lon,'lat':lat}
            except ValueError:pass
        features.append({'id':'amap:'+text(poi.get('id')),'name':text(poi.get('name')),'sourceId':src['id'],'crs':'GCJ-02','center':point,'address':text(poi.get('address')),'type':text(poi.get('type')),'geometry':[],
          'height':None,'levels':None,'estimatedHeight':None,'style':{},'note':'POI identifies a place, not a surveyed building. Indoor floor indicators are not building floor counts.'})
    src['reportedCount']=raw.get('count');src['returnedCount']=len(features)
    return envelope(src,features,['One page only; results do not imply full campus coverage.','GCJ-02 coordinates must not be overlaid directly on WGS84 coordinates.','This POI adapter provides no guaranteed height, footprint, roof or facade data.'])

def validate_evidence(data):
    if data.get('format')!='campus-map-evidence' or data.get('version')!=1:raise ValueError('Unsupported evidence file.')
    if not isinstance(data.get('sources'),list) or not isinstance(data.get('features'),list):raise ValueError('Evidence needs sources and features arrays.')
    ids=set()
    for item in data['sources']:
        if not isinstance(item,dict) or not isinstance(item.get('id'),str) or not item['id'] or item['id'] in ids:raise ValueError('Evidence sources need unique nonempty IDs.')
        if not isinstance(item.get('url'),str) or not item['url'].startswith(('https://','http://')):raise ValueError('Evidence source needs its public URL.')
        ids.add(item['id'])
    for feature in data['features']:
        if not isinstance(feature,dict) or feature.get('sourceId') not in ids:raise ValueError('Feature refers to an unknown source.')
    return data

def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='provider',required=True)
    osm=sub.add_parser('osm');osm.add_argument('--bbox',required=True,help='south,west,north,east in WGS84, <= 0.08 degrees per axis');osm.add_argument('--endpoint',choices=ENDPOINTS,default='de');osm.add_argument('--floor-height',type=float,help='Optional explicit estimate, metres per floor; omitted means no estimate')
    amap=sub.add_parser('amap');amap.add_argument('--keywords',required=True);amap.add_argument('--city',required=True);amap.add_argument('--page',type=int,default=1);amap.add_argument('--key-env',default='AMAP_WEB_SERVICE_KEY')
    for command in (osm,amap):command.add_argument('--response',help='Normalize an existing API JSON response without any network call');command.add_argument('--out',required=True)
    args=parser.parse_args();output=Path(args.out).resolve()
    if output.exists():raise FileExistsError('Output already exists; choose a new evidence filename.')
    raw=json.loads(Path(args.response).read_text(encoding='utf-8-sig')) if args.response else None
    if args.provider=='osm':
        bbox=list(map(float,args.bbox.split(',')))
        if len(bbox)!=4:raise ValueError('bbox needs south,west,north,east.')
        s,w,n,e=bbox
        if not (-90<=s<n<=90 and -180<=w<e<=180 and n-s<=.08 and e-w<=.08):raise ValueError('Use a small WGS84 campus bounding box, no more than 0.08 degrees per axis.')
        if args.floor_height is not None and not 2<=args.floor_height<=6:raise ValueError('Explicit floor-height estimate must be 2 to 6 metres.')
        box=','.join(map(str,bbox));query=f'[out:json][timeout:25][maxsize:8388608];(nwr["building"]({box});nwr["building:part"]({box}););out body geom;'
        if raw is None:raw=fetch(ENDPOINTS[args.endpoint],urlencode({'data':query}).encode())
        result=normalize_osm(raw,source('osm',ENDPOINTS[args.endpoint],'WGS84',{'bbox':bbox},raw,bool(args.response)),args.floor_height)
    else:
        if not 1<=args.page<=10:raise ValueError('page must be 1 to 10; queries are intentionally bounded.')
        query={'keywords':args.keywords,'city':args.city,'citylimit':'true','offset':25,'page':args.page,'extensions':'base','output':'JSON'}
        if raw is None:
            key=os.environ.get(args.key_env)
            if not key:raise ValueError(f'Set the {args.key_env} environment variable to a Web Service Key, or use OSM/official school sources. No Key is needed for offline response normalization.')
            raw=fetch(AMAP+'?'+urlencode({**query,'key':key}))
        result=normalize_amap(raw,source('amap',AMAP,'GCJ-02',query,raw,bool(args.response)))
    validate_evidence(result);output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'evidence':str(output),'coverage':result['coverage'],'warnings':result['warnings']},ensure_ascii=False))

if __name__=='__main__':
    try:main()
    except Exception as error:print(f'Map evidence failed: {error}',file=sys.stderr);sys.exit(1)
