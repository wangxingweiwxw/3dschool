"""Offline tests; fixtures are synthetic, not real queried buildings."""
import json,unittest
from map_evidence import metres,normalize_osm,normalize_amap,source,validate_evidence

class EvidenceTests(unittest.TestCase):
    def test_units_and_missing_values(self):
        self.assertEqual(metres('42.5 m'),42.5)
        self.assertEqual(metres('100 ft'),30.48)
        self.assertEqual(metres('0'),0)
        for value in ('10;12','unknown',None,[],'-3','inf'):self.assertIsNone(metres(value))

    def test_explicit_vs_estimated(self):
        raw={'elements':[{'type':'way','id':1,'tags':{'building':'yes','name':'Synthetic A','height':'12 m','building:levels':'3','roof:shape':'hipped'}},
                         {'type':'way','id':2,'tags':{'building':'yes','building:levels':'4','roof:height':'0'}},
                         {'type':'way','id':3,'tags':{'building':'yes','ele':'100'}},
                         {'type':'relation','id':4,'tags':{'building':'yes'},'members':[{'role':'inner','geometry':[{'lat':1,'lon':2},{'lat':2,'lon':3}]}]}]}
        src=source('osm','https://overpass-api.de/api/interpreter','WGS84',{},raw,True)
        unknown=normalize_osm(raw,src);self.assertIsNone(unknown['features'][1]['estimatedHeight'])
        result=normalize_osm(raw,src,3.2);validate_evidence(result)
        a,b,c,d=result['features']
        self.assertEqual(a['height']['value'],12);self.assertIsNone(a['estimatedHeight'])
        self.assertEqual(b['estimatedHeight']['value'],12.8);self.assertIsNone(b['height']);self.assertFalse(b['estimatedHeight']['assumptions']['roofHeightUnknown'])
        self.assertIsNone(c['height']);self.assertEqual(d['geometry'][0]['role'],'inner');self.assertFalse(d['geometry'][0]['closed'])
        self.assertEqual(result['coverage']['explicitHeight'],1);self.assertIsNone(src['retrievedAt'])

    def test_poi_is_not_building_geometry(self):
        raw={'status':'1','count':'80','pois':[{'id':'synthetic','name':'Synthetic school','location':'121.5,31.2','indoor_data':{'floor':'5'},'height':'999','address':[],'photos':[{'url':'not-used'}]}]}
        src=source('amap','https://restapi.amap.com/v3/place/text','GCJ-02',{'keywords':'Synthetic'},raw,True)
        result=normalize_amap(raw,src);f=result['features'][0];validate_evidence(result)
        self.assertEqual(f['crs'],'GCJ-02');self.assertIsNone(f['height']);self.assertIsNone(f['levels']);self.assertEqual(f['geometry'],[]);self.assertEqual(src['returnedCount'],1)
        self.assertNotIn('indoor_data',json.dumps(result));self.assertNotIn('photos',json.dumps(result))

    def test_failures_not_silently_empty(self):
        with self.assertRaises(ValueError):normalize_osm({'elements':[],'remark':'timeout'},{})
        with self.assertRaisesRegex(ValueError,'10001'):normalize_amap({'status':'0','infocode':'10001','info':'secret-key-value'},{})
        with self.assertRaises(ValueError):validate_evidence({'format':'campus-map-evidence','version':1,'sources':[],'features':[{'sourceId':'missing'}]})

if __name__=='__main__':unittest.main()
