"""Audit a generated directory or ZIP: assets, hashes, GLB structure and route coverage."""
import argparse,hashlib,json,math,struct,sys,zipfile
from pathlib import Path

REQUIRED={'campus.json','campus.glb','preview.png','validation.json','layout-analysis.json','IMPORT.md','manifest.json'}

def audit(path):
    path=Path(path)
    if path.is_dir():
        files={p.name:p.read_bytes() for p in path.iterdir() if p.is_file()}
    else:
        with zipfile.ZipFile(path) as archive:
            if sum(i.file_size for i in archive.infolist())>512*1024*1024: raise ValueError('Expanded package exceeds audit limit 512 MB.')
            candidates=[n for n in archive.namelist() if n=='campus.json' or n.endswith('/campus.json')]
            if len(candidates)!=1: raise ValueError('Expected exactly one campus.json.')
            prefix=candidates[0][:-len('campus.json')]
            names=[n for n in archive.namelist() if n.startswith(prefix) and '/' not in n[len(prefix):] and not n.endswith('/')]
            if len(names)!=len(set(names)): raise ValueError('Duplicate ZIP entry.')
            files={n[len(prefix):]:archive.read(n) for n in names}
    missing=REQUIRED-files.keys()
    if missing: raise ValueError('Incomplete model package; missing '+', '.join(sorted(missing)))
    read=lambda n:json.loads(files[n].decode('utf-8-sig'))
    manifest=read('manifest.json'); payload=read('campus.json'); c=payload['campus']; report=read('validation.json')
    if manifest.get('id')!=c['id'] or report.get('id')!=c['id']: raise ValueError('Campus IDs do not match.')
    for name in REQUIRED-{'manifest.json'}:
        if name not in manifest['files']: raise ValueError(f'Manifest does not cover required file: {name}')
    for name,digest in manifest['files'].items():
        if name not in files or hashlib.sha256(files[name]).hexdigest()!=digest: raise ValueError('Checksum failed: '+name)
    glb=files['campus.glb']
    if len(glb)<28 or struct.unpack('<4sII',glb[:12])!=(b'glTF',2,len(glb)): raise ValueError('Invalid GLB header/length.')
    offset=12; chunks={}
    while offset<len(glb):
        if offset+8>len(glb): raise ValueError('Truncated GLB chunk.')
        size,kind=struct.unpack('<II',glb[offset:offset+8]);offset+=8
        if size%4 or offset+size>len(glb) or kind in chunks: raise ValueError('Invalid GLB chunk.')
        chunks[kind]=glb[offset:offset+size];offset+=size
    scene=json.loads(chunks[0x4e4f534a]);binary=chunks.get(0x004e4942,b'')
    buffers=scene.get('buffers',[])
    if len(buffers)!=1 or buffers[0].get('uri') or not 0<=len(binary)-buffers[0]['byteLength']<=3: raise ValueError('GLB is not self-contained.')
    primitives=[p for m in scene.get('meshes',[]) for p in m.get('primitives',[])]
    if not primitives: raise ValueError('GLB contains no geometry.')
    for p in primitives:
        accessor=scene['accessors'][p['attributes']['POSITION']]
        if accessor['count']<3: raise ValueError('Empty position accessor.')
        for key in ('min','max'):
            if not all(math.isfinite(v) for v in accessor.get(key,[])): raise ValueError('Invalid geometry bounds.')
    for view in scene.get('bufferViews',[]):
        if view.get('buffer',0)!=0 or view.get('byteOffset',0)+view['byteLength']>len(binary): raise ValueError('Buffer view out of bounds.')
    if any(i.get('uri') for i in scene.get('images',[])): raise ValueError('External textures in GLB.')
    if not files['preview.png'].startswith(b'\x89PNG\r\n\x1a\n'): raise ValueError('Invalid preview PNG.')
    expected={m['id'] for m in c['landmarks']+c['memories']}
    routes=report.get('routes',[])
    if len(routes)!=len(expected) or {r['id'] for r in routes}!=expected or not all(r.get('reachable') for r in routes): raise ValueError('Route report does not cover all destinations.')
    if not report.get('spawnClear') or not report.get('glb',{}).get('roundTripLoaded'): raise ValueError('Missing successful runtime validation.')
    if report['glb']['bytes']!=len(glb) or report['buildings']!=sum(r['type']=='building' for r in c['regions']): raise ValueError('Validation counts do not match payload.')
    warnings=[]
    if 'quality.json' in files:
        quality=read('quality.json')
        if not quality.get('passed'): raise ValueError('Quality review failed.')
        warnings.extend(quality.get('warnings',[]))
        if quality.get('profile')!='complete':warnings.append('This package was built as a draft, not complete deliverable.')
    else:warnings.append('Legacy package: no inventory quality report.')
    if len(files['campus.json'])>2*1024*1024:warnings.append('JSON exceeds web import limit 2 MB.')
    if path.is_file() and path.stat().st_size>80*1024*1024:warnings.append('ZIP exceeds 80 MB web import limit; use JSON.')
    return dict(passed=True,id=c['id'],buildings=report['buildings'],routes=len(routes),glbBytes=len(glb),
                meshes=len(scene['meshes']),primitives=len(primitives),embeddedImages=len(scene.get('images',[])),
                trees=report.get('trees'),warnings=warnings,
                note='Structural audit does not prove geographic accuracy. Compare preview with source map and inspect evidence.')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('package');args=parser.parse_args()
    try: print(json.dumps(audit(args.package),ensure_ascii=False,indent=2))
    except Exception as error:print('Package audit failed: '+str(error),file=sys.stderr);sys.exit(1)
