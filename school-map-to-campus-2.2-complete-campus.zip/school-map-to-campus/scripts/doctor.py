"""Verify bundled files and discover a local browser. No downloads or installation."""
import argparse,json,sys
from standalone_runtime import find_browser,verify_runtime

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--browser');args=p.parse_args()
    try:
        manifest=verify_runtime()
        print(json.dumps({'ok':True,'generator':manifest['version'],'python':sys.version.split()[0],'browser':str(find_browser(args.browser)),'bundledFiles':len(manifest['files']),'requiresProject':False,'requiresNode':False,'requiresPip':False},ensure_ascii=False))
    except Exception as error:
        print(f'Environment check failed: {error}',file=sys.stderr);sys.exit(1)
