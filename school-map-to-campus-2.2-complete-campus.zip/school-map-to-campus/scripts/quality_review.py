"""Check authored map coverage; counts come from the map inventory, not a MB quota."""
def review(payload, profile='complete'):
    campus=payload['campus']; source=payload.get('source',{})
    regions={r['id']:r for r in campus['regions']}
    buildings=[r for r in regions.values() if r['type']=='building']
    errors=[]; warnings=[]
    plan=source.get('modelingPlan',{})
    inventory=plan.get('inventory',[])
    research=source.get('researchLog',[])
    represented=set(); omissions=[]
    if profile=='complete':
        if source.get('kind')=='synthetic-template': errors.append('Four-building format template is a draft; use the actual map or explicitly --profile draft.')
        if not inventory: errors.append('source.modelingPlan.inventory is required: list observed buildings/gates/sports/water and their regionIds or omissionReason.')
        if not plan.get('mapBasis'): errors.append('modelingPlan.mapBasis must identify the input map and interpretation scope.')
        if not research: errors.append('source.researchLog must record searches, or an explicit offline/unavailable/user-prohibited status.')
    seen=set()
    for item in inventory:
        item_id=item.get('id')
        if not item_id or item_id in seen: errors.append('Inventory IDs must be present and unique.')
        seen.add(item_id)
        ids=item.get('regionIds',[])
        if not ids:
            if not item.get('omissionReason'): errors.append(f'{item_id}: missing modeled regions or omission reason.')
            else: omissions.append({'id':item_id,'reason':item['omissionReason']})
        for id in ids:
            if id not in regions: errors.append(f'{item_id}: unknown modeled region {id}.')
            represented.add(id)
    unresolved=[]
    for r in buildings:
        id=r['id']
        if profile=='complete' and id not in represented: errors.append(f'{id}: building absent from inventory.')
        record=next((x for x in inventory if id in x.get('regionIds',[])),{})
        pending=record.get('nameStatus')=='unresolved' or '未标注' in r['label'] or '待核实' in r['label']
        if pending:
            unresolved.append(id)
            if r.get('recipe')=='teaching-block' and r.get('showSign') is not False:
                errors.append(f'{id}: unresolved name must use showSign=false; keep uncertainty in source metadata.')
            if profile=='complete' and not record.get('uncertaintyReason'): errors.append(f'{id}: explain unresolved identity in uncertaintyReason.')
        if profile=='complete' and r.get('recipe') in ('ceremonial-gate','small-gate'):
            orientation=record.get('orientation',{})
            if not orientation.get('basis') or not orientation.get('passageAxis'):
                errors.append(f'{id}: gate needs orientation.basis and passageAxis (east-west / north-south).')
    if omissions: warnings.append('Some observed features were explicitly omitted; inspect omissions before claiming whole-campus coverage.')
    if unresolved: warnings.append('Some building identities remain unresolved; hidden signs are not verified names.')
    if any(x.get('status') in ('offline','unavailable','user-prohibited') for x in research):
        warnings.append('External research was limited; do not claim all building facts were verified online.')
    return {'profile':profile,'passed':not errors,'errors':errors,'warnings':warnings,
            'buildings':len(buildings),'inventoryItems':len(inventory),'modeledInventoryItems':sum(bool(i.get('regionIds')) for i in inventory),
            'omissions':omissions,'unresolvedBuildings':unresolved,
            'note':'Inventory is agent-authored evidence, not automatic proof of image completeness. Human/agent visual comparison is still required. ZIP size is not an accuracy metric.'}
