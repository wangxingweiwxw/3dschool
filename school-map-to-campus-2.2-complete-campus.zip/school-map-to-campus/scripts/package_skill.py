"""Validate the runtime inventory and ZIP the complete relocatable skill."""
import argparse,ast,hashlib,json,re,zipfile
from pathlib import Path
from standalone_runtime import SKILL_ROOT,RUNTIME,verify_runtime

def check_imports():
    for path in RUNTIME.rglob('*.js'):
        source=path.read_text(encoding='utf-8')
        source=re.sub(r'/\*.*?\*/','',source,flags=re.S)
        source=re.sub(r'^\s*//.*$','',source,flags=re.M)
        imports=re.findall(r'''^\s*import\s+(?:[\w*{},\s]+?\s+from\s+)?['"]([^'"]+)['"]''',source,re.M)
        imports+=re.findall(r'''\bimport\s*\(\s*['"]([^'"]+)['"]''',source)
        imports+=re.findall(r'''^\s*export\s+(?:\*|\{[^}]*\})\s+from\s+['"]([^'"]+)['"]''',source,re.M)
        for spec in imports:
            if spec=='three':target=RUNTIME/'vendor/three/build/three.module.js'
            elif spec.startswith('three/addons/'):target=RUNTIME/'vendor/three/examples/jsm'/spec[len('three/addons/'):]
            elif spec.startswith('.'):target=(path.parent/spec).resolve()
            else:raise ValueError(f'Unbundled module specifier: {spec} in {path}')
            if not target.is_file() or not target.resolve().is_relative_to(RUNTIME.resolve()):raise ValueError(f'Missing bundled dependency: {spec} in {path}')

def inventory():
    check_imports()
    files={p.relative_to(RUNTIME).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(RUNTIME.rglob('*')) if p.is_file() and p.name!='manifest.json'}
    (RUNTIME/'manifest.json').write_text(json.dumps({'version':'2.2.0-complete-campus','format':'3dschool-campus','formatVersion':1,'three':'0.170.0','files':files},ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',required=True);p.add_argument('--refresh-inventory',action='store_true',help='Maintainer option, only after intentional runtime edits');args=p.parse_args()
    if args.refresh_inventory:inventory()
    verify_runtime();check_imports()
    for script in (SKILL_ROOT/'scripts').glob('*.py'):ast.parse(script.read_text(encoding='utf-8'))
    output=Path(args.out).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    if output.is_relative_to(SKILL_ROOT):raise ValueError('ZIP output must be outside the skill directory')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for file in sorted(SKILL_ROOT.rglob('*')):
            if file.is_file() and '__pycache__' not in file.parts and file.suffix!='.pyc':z.write(file,str(Path(SKILL_ROOT.name)/file.relative_to(SKILL_ROOT)))
    digest=hashlib.sha256(output.read_bytes()).hexdigest();output.with_suffix(output.suffix+'.sha256').write_text(f'{digest}  {output.name}\n',encoding='ascii')
    print(json.dumps({'zip':str(output),'bytes':output.stat().st_size,'sha256':digest}))
