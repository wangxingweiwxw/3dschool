"""Build a standalone campus GLB + playable JSON package using bundled assets."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
import zipfile
from standalone_runtime import generate
from map_evidence import validate_evidence
from quality_review import review
from check_package import audit


def build(args):
    payload=json.loads(Path(args.input).read_text(encoding='utf-8-sig'))
    slug=payload.get('campus',{}).get('id','')
    if not isinstance(slug,str) or not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,79}',slug):
        raise ValueError('campus.id must be a lowercase folder-safe slug.')
    output=Path(args.out).expanduser().resolve()/slug
    archive=output.with_suffix('.zip')
    if output.exists() or archive.exists():
        raise FileExistsError(f'Choose a new output directory; refusing to overwrite {output}')
    evidence=[validate_evidence(json.loads(Path(path).read_text(encoding='utf-8-sig'))) for path in (args.evidence or [])]
    if evidence:
        if not isinstance(payload.get('source',{}),dict):raise ValueError('source must be an object')
        sources=[source for dataset in evidence for source in dataset['sources']]
        payload.setdefault('source',{})['externalSources']=sources
        payload['source']['evidenceNote']='Evidence is supplied for traceability. Applied fields and modeling decisions are recorded by the author in source.evidenceMatches; no automatic geometry overwrite.'
    quality=review(payload,args.profile)
    if not quality['passed']:raise ValueError('Quality review: '+'; '.join(quality['errors']))
    binary,preview,report=generate(payload,args.browser,args.timeout)
    output.mkdir(parents=True)
    (output/'campus.glb').write_bytes(binary)
    result={'report':report}
    glb=(output/'campus.glb').read_bytes()
    if len(glb)<20 or struct.unpack('<4sII',glb[:12])!=(b'glTF',2,len(glb)):
        raise ValueError('Downloaded GLB header or byte length is invalid.')
    (output/'preview.png').write_bytes(preview)
    def write(name,value):
        (output/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    write('campus.json',payload)
    write('validation.json',result['report'])
    write('layout-analysis.json',payload.get('source',{'note':'No map interpretation notes were supplied.'}))
    write('quality.json',quality)
    if evidence:
        write('evidence.json',{'format':'campus-research-bundle','version':1,'datasets':evidence})
        notices=['# 公开资料来源与建模依据','', '下列资料供核对与追溯；实际采用字段见 campus.json 的 source.evidenceMatches。缺失高度或外观仍需明确标注估测。','']
        for source in sources:
            notices.extend([f"- {source.get('attribution',source.get('provider','Source'))}: {source.get('url','')}",f"  - Retrieved: {source.get('retrievedAt') or 'unknown / supplied response'}; license: {source.get('license','Check source terms')}",f"  - License URL: {source.get('licenseUrl','')}"])
        (output/'SOURCES.md').write_text('\n'.join(notices)+'\n',encoding='utf-8')
    (output/'IMPORT.md').write_text(f'''# {payload['campus']['name']} · 校园模型包

- `campus.glb`：已建成的静态 3D 校园模型，含嵌入纹理；可在支持 glTF 2.0 / EXT_mesh_gpu_instancing 的查看器中打开。
- `campus.json`：3Dschool 可玩校园。使用项目建模配方重建同一布局，保留寻路、碰撞、三角色、夜景与建筑透视。
- `preview.png`：导出 GLB 重新加载后的实拍预览。
- `validation.json`：真实碰撞检测、出生点与全部地标/记忆的寻路验证、GLB 回读结果。
- `layout-analysis.json`：地图解释、估测和未确定内容。

## 导入已支持校园包的 3Dschool

网页导入：点击右上角“校园”，选择本包的 `campus.json` 或完整 ZIP，再点击“进入这座校园”。文件仅保存在当前网站的浏览器中；刷新后可继续，换设备需重新导入。

随网站发布给所有玩家：
将 `campus.json` 复制到 `public/campuses/{slug}/campus.json`，打开 `http://127.0.0.1:5173/?campus={slug}`。
也可运行技能中的 `scripts/import_package.py --package "本文件所在文件夹" --project "3Dschool项目路径"`。
不带 campus 参数仍使用原有复旦校园；每个校园独立存档。部署前重新构建项目，再上传 dist 全部内容。

GLB 是静态模型交付件，不能单独替代任务、碰撞和动画系统。漫游入口读取 JSON，GLB 不必复制到 public。
高度与造型如采用外部资料，见 campus.json/source 中的采用记录及随包 SOURCES.md；缺失的高度、屋顶、立面和植物细节为艺术化推定，非建筑实测。
''',encoding='utf-8')
    files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir() if p.is_file()}
    write('manifest.json',{'format':'3dschool-campus-package','version':1,'id':slug,'entry':'campus.json','model':'campus.glb','files':files})
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for path in output.iterdir():z.write(path,f'{slug}/{path.name}')
    checked=audit(archive)
    print(json.dumps({'package':str(output),'zip':str(archive),'modelBytes':len(glb),'routes':len(result['report']['routes']),'audit':checked},ensure_ascii=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',required=True,help='Authored campus.json envelope, not the raw map image')
    parser.add_argument('--out',required=True,help='Output parent; creates a new campus-id directory and ZIP')
    parser.add_argument('--browser','--chrome',dest='browser',help='Optional path to Chrome, Edge or Chromium')
    parser.add_argument('--timeout',type=int,default=240,help='Browser build time limit in seconds')
    parser.add_argument('--evidence',action='append',help='Optional normalized public map/official-source evidence JSON; repeat for multiple sources')
    parser.add_argument('--profile',choices=['complete','draft'],default='complete',help='Default complete requires a map inventory and research log; draft is explicitly incomplete')
    try:build(parser.parse_args())
    except Exception as error:
        print(f'Campus build failed: {error}',file=sys.stderr);sys.exit(1)
