"""Install only the playable JSON; never replace the default campus or saves."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil


def install(args):
    package=Path(args.package).resolve();project=Path(args.project).resolve()
    manifest=json.loads((package/'manifest.json').read_text(encoding='utf-8'))
    if manifest.get('format')!='3dschool-campus-package' or manifest.get('version')!=1:
        raise ValueError('Unsupported package manifest')
    if not {'campus.json','campus.glb','preview.png','validation.json'}.issubset(manifest.get('files',{})):
        raise ValueError('Manifest is missing required package files')
    for name,digest in manifest['files'].items():
        if Path(name).name!=name or '/' in name or '\\' in name:
            raise ValueError('Manifest files must be direct children of the package')
        if hashlib.sha256((package/name).read_bytes()).hexdigest()!=digest:
            raise ValueError(f'Package checksum mismatch: {name}')
    payload=json.loads((package/'campus.json').read_text(encoding='utf-8'))
    slug=payload.get('campus',{}).get('id','')
    if payload.get('format')!='3dschool-campus' or payload.get('version')!=1 or not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,79}',slug) or slug!=manifest['id']:
        raise ValueError('Invalid campus entry')
    if not (project/'src/data/campusPackage.js').is_file():raise ValueError('Project lacks the campus-package loader')
    target=project/'public/campuses'/slug/'campus.json'
    if target.exists():raise FileExistsError(f'Refusing to overwrite existing campus: {target}')
    if not args.dry_run:
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(package/'campus.json',target)
    print(json.dumps({'target':str(target),'open':f'http://127.0.0.1:5173/?campus={slug}','dryRun':args.dry_run},ensure_ascii=False))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--package',required=True);p.add_argument('--project',required=True);p.add_argument('--dry-run',action='store_true')
    install(p.parse_args())
