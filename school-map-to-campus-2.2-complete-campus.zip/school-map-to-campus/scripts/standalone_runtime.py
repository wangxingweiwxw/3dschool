"""Portable stdlib-only runner. Serves bundled files to an isolated local browser."""
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import unquote,urlsplit

SKILL_ROOT=Path(__file__).resolve().parents[1]
RUNTIME=SKILL_ROOT/'runtime'

def find_browser(explicit=None):
    if explicit:
        path=Path(explicit).expanduser().resolve()
        if not path.is_file():raise FileNotFoundError(f'Browser executable does not exist: {path}')
        return path
    candidates=[]
    if sys.platform=='win32':
        for variable in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA'):
            base=os.environ.get(variable)
            if base:
                candidates.extend(Path(base)/suffix for suffix in ('Google/Chrome/Application/chrome.exe','Microsoft/Edge/Application/msedge.exe','Chromium/Application/chrome.exe'))
    elif sys.platform=='darwin':
        candidates.extend([Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'),Path('/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'),Path('/Applications/Chromium.app/Contents/MacOS/Chromium')])
    for command in ('google-chrome','google-chrome-stable','chromium','chromium-browser','microsoft-edge','msedge'):
        found=shutil.which(command)
        if found:candidates.append(Path(found))
    for candidate in candidates:
        if candidate.is_file():return candidate.resolve()
    raise RuntimeError('Chrome/Edge/Chromium was not found. Install a current desktop browser or pass --browser PATH. No 3Dschool, Node.js, npm, Vite or Playwright is required.')

def verify_runtime():
    if sys.version_info<(3,10):raise RuntimeError('Python 3.10 or later is required.')
    manifest=json.loads((RUNTIME/'manifest.json').read_text(encoding='utf-8'))
    for relative,digest in manifest['files'].items():
        path=(RUNTIME/relative).resolve()
        if not path.is_relative_to(RUNTIME.resolve()) or not path.is_file():raise RuntimeError(f'Missing runtime file: {relative}')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise RuntimeError(f'Runtime checksum mismatch: {relative}; reinstall the complete skill package.')
    return manifest

def generate(payload,browser=None,timeout=240):
    manifest=verify_runtime();executable=find_browser(browser)
    secret=secrets.token_urlsafe(24);prefix='/run/'+secret+'/'
    complete=threading.Event();state={};requests=[]
    encoded=json.dumps(payload,ensure_ascii=False).encode('utf-8')
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def reply(self,code,data=b'',mime='text/plain; charset=utf-8'):
            self.send_response(code);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
        def do_GET(self):
            path=unquote(urlsplit(self.path).path);requests.append(path)
            if path==prefix+'input':return self.reply(200,encoded,'application/json; charset=utf-8')
            if path.startswith('/runtime/'):
                file=(RUNTIME/path[len('/runtime/'):]).resolve()
                if file.is_relative_to(RUNTIME.resolve()) and file.is_file():
                    mime={'.js':'text/javascript; charset=utf-8','.html':'text/html; charset=utf-8','.json':'application/json'}.get(file.suffix,'application/octet-stream')
                    return self.reply(200,file.read_bytes(),mime)
            self.reply(404)
        def do_POST(self):
            limits={'model':160*1024*1024,'preview':20*1024*1024,'complete':4*1024*1024,'error':65536}
            path=urlsplit(self.path).path;name=path[len(prefix):] if path.startswith(prefix) else ''
            try:length=int(self.headers.get('Content-Length','0'))
            except ValueError:return self.reply(400)
            if name not in limits or not 0<length<=limits[name]:return self.reply(400)
            data=self.rfile.read(length)
            if len(data)!=length:return self.reply(400)
            state[name]=data;self.reply(200,b'ok')
            if name in ('complete','error'):complete.set()
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        with tempfile.TemporaryDirectory(prefix='school-map-browser-') as profile:
            url=f'http://127.0.0.1:{server.server_port}/runtime/index.html?token={secret}'
            command=[str(executable),'--headless=new','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--disable-background-timer-throttling','--disable-renderer-backgrounding','--enable-webgl','--ignore-gpu-blocklist','--enable-unsafe-swiftshader','--remote-debugging-port=0',f'--user-data-dir={profile}',url]
            if hasattr(os,'geteuid') and os.geteuid()==0:command.append('--no-sandbox')
            with tempfile.TemporaryFile() as log:
                process=subprocess.Popen(command,stdout=log,stderr=log,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                try:
                    deadline=time.monotonic()+timeout
                    while not complete.wait(.2):
                        if process.poll() is not None:raise RuntimeError('Browser exited before generating the campus. Check browser/WebGL support.')
                        if time.monotonic()>deadline:raise TimeoutError(f'Campus generation exceeded {timeout}s. Use --timeout for larger maps; check browser/WebGL support.')
                    if 'error' in state:raise RuntimeError(json.loads(state['error'])['message'])
                    if not all(key in state for key in ('model','preview','complete')):raise RuntimeError('Incomplete model output from browser')
                    report=json.loads(state['complete']);report['generator']={'version':manifest['version'],'three':manifest['three'],'standalone':True,'runtimeFilesRequested':sorted({p for p in requests if p.startswith('/runtime/')}),'projectRequired':False}
                    return state['model'],state['preview'],report
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:process.wait(timeout=10)
                        except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
    finally:
        server.shutdown();server.server_close();thread.join(timeout=2)
