# Bundled code

`vendor/three/` contains the necessary browser ES modules from Three.js **0.170.0**:
the core module, GLTFExporter, GLTFLoader, CSS2DRenderer and BufferGeometryUtils.
Three.js is distributed under the MIT license; the complete license and copyright
notice are included at `vendor/three/LICENSE`. These are local copies, not CDN links.

`src/` is a snapshot of the campus generator, recipe, procedural texture, collision
and navigation modules created for this 3Dschool project. The snapshot serves the
v1 campus JSON format and does not load code from any external project. No user
map photographs, character portraits, credentials, node_modules directory, or
browser profile are included. Textures are generated from code during each build.

Python and a platform-compatible Chrome / Edge / Chromium browser are execution
prerequisites, not bundled executables. The generator uses only the Python standard
library and serves its assets over a temporary loopback HTTP port. It does not
install packages or fetch JavaScript from the internet.
