const endpoint='/run/'+new URLSearchParams(location.search).get('token')+'/';
const post=async(name,data)=>{
 const response=await fetch(endpoint+name,{method:'POST',body:data});
 if(!response.ok)throw new Error(`写入 ${name} 失败：${response.status}`);
};
try{
 const response=await fetch(endpoint+'input');
 if(!response.ok)throw new Error('输入读取失败');
 const payload=await response.json();
 const {buildCampusPackage}=await import('./src/tools/campusPackageBuilder.js');
 const result=await buildCampusPackage(payload);
 await post('model',result.binary);
 const preview=await(await fetch(result.preview)).blob();
 await post('preview',preview);
 await post('complete',JSON.stringify(result.report));
 document.getElementById('status').textContent='模型生成完成。';
}catch(error){
 document.getElementById('status').textContent=error.message;
 await post('error',JSON.stringify({message:error.message,stack:error.stack}));
}
